function onCreate()
    makeAnimatedLuaSprite('bg', 'Background', -2160 + 2180)

    setProperty('bg.y', 50)

    addAnimationByPrefix('bg', 'idle', 'Passiva', 36, true)
    objectPlayAnimation('bg', 'idle', true)

    setGraphicSize('bg', getProperty('bg.width') * 4.0)
    updateHitbox('bg')

    addLuaSprite('bg', false)
end

-- by mathexs